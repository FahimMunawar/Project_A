-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2021 at 11:05 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `ID` int(100) DEFAULT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`ID`, `Name`, `email`, `password`) VALUES
(1, 'Md. Munawar Hossain', 'ruet@gmail.com', 'ruetadmin');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `Roll_no` int(100) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Gender` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `DoB` varchar(100) NOT NULL,
  `Address` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`Roll_no`, `Name`, `Email`, `Gender`, `contact`, `DoB`, `Address`) VALUES
(1, 'Munawar ', 'munawark7@gmail.com', 'Male', '321837678', '2-32-32', 'Kazla\n\n\n'),
(2, 'Fahim', 'munawark2@gmail.com', 'Male', '09021839', '2/02/2000', 'Kajlaaa\n'),
(3, 'Nadim', 'nadim@gmail.com', 'Female', '0128732873', '923883994', 'Natore\n'),
(4, 'Rahim', 'rahim001@gmail.com', 'Male', '193210-3', '3213213', '313213\n');

-- --------------------------------------------------------

--
-- Table structure for table `student_register`
--

CREATE TABLE `student_register` (
  `ID` int(100) NOT NULL,
  `f_name` varchar(50) NOT NULL,
  `l_name` varchar(50) NOT NULL,
  `dept` varchar(50) NOT NULL,
  `Roll` varchar(10) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `email` varchar(50) NOT NULL,
  `question` varchar(100) NOT NULL,
  `answer` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_register`
--

INSERT INTO `student_register` (`ID`, `f_name`, `l_name`, `dept`, `Roll`, `contact`, `email`, `question`, `answer`, `password`) VALUES
(5, 'Md. Munawar', 'Hossain', 'ECE', '1710029', '0173525885', 'munawark7@gmail.com', 'Your Birth Place', 'Mirpur', 'joseph'),
(6, '23', '21', 'CSE', '32', '12', '323', 'Your Birth Place', '321', '32'),
(7, 'Shaznin ', 'Ishrat', 'CSE', '1703039', '01724395772', 'shaznin.ishrat@gmail.com', 'Your First Pet Name', 'Parrot', 'trina123'),
(8, 'Asif', 'Iqbal', 'ECE', '1710020', '017000000', 'asif@gmail.com', 'Your Birth Place', 'Dhaka', 'joseph183'),
(9, 'Fahim', 'Munawar', 'ECE', '1710029', '01834284293', 'fahim@gmail.com', 'Your Birth Place', 'Dhaka', 'fahimece'),
(10, 'Rahim', 'Islam', 'EEE', '1710003', '10231098310923', 'rahim@gmail.com', 'Your Birth Place', 'Mirpur', 'ruetece'),
(11, 'Nadim', 'Reza', 'ECE', '1710029', '0219038109', 'nadim@gmail.com', 'Your Birth Place', 'Natore', 'nadim0002');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `ID_no` int(100) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Gender` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `DoB` varchar(100) NOT NULL,
  `Address` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`ID_no`, `Name`, `Email`, `Gender`, `contact`, `DoB`, `Address`) VALUES
(101, 'Fahim', 'gahim@gmail.com', 'Male', '4354665', '12/03/1992', 'Dhaka\n');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_register`
--

CREATE TABLE `teacher_register` (
  `ID` int(100) NOT NULL,
  `f_name` varchar(50) DEFAULT NULL,
  `l_name` varchar(50) DEFAULT NULL,
  `dept` varchar(10) DEFAULT NULL,
  `Designation` varchar(50) DEFAULT NULL,
  `contact` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `question` varchar(50) DEFAULT NULL,
  `answer` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teacher_register`
--

INSERT INTO `teacher_register` (`ID`, `f_name`, `l_name`, `dept`, `Designation`, `contact`, `email`, `question`, `answer`, `password`) VALUES
(1, 'cgdc', 'gfdg', 'CE', 'Lecturer', 'fsd', 'dsfsdf', 'Your First Pet Name', 'fsdf', 'fffffd'),
(2, 'fsdf', 'fs', 'CE', 'Asst. Professor', 'dsffd', 'fdsf', 'Your Birth Place', 'fdsf', 'dsf'),
(3, 'Fahim', 'Munawar', 'EEE', 'Asst. Professor', '01983982224', 'munawark7@gmail.com', 'Your Birth Place', 'Mirpur', 'robi001');

-- --------------------------------------------------------

--
-- Table structure for table `temp`
--

CREATE TABLE `temp` (
  `ID` int(11) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `temp2`
--

CREATE TABLE `temp2` (
  `ID` int(11) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `temp2`
--

INSERT INTO `temp2` (`ID`, `email`) VALUES
(1, '323'),
(2, 'asif@gmail.com'),
(3, '323'),
(4, '323'),
(5, 'munawark7@gmail.com'),
(6, 'munawark7@gmail.com'),
(7, 'munawark7@gmail.com'),
(8, 'munawark7@gmail.com'),
(9, 'munawark7@gmail.com'),
(10, 'munawark7@gmail.com'),
(11, 'munawark7@gmail.com'),
(12, 'munawark7@gmail.com'),
(13, 'munawark7@gmail.com'),
(14, 'munawark7@gmail.com'),
(15, 'munawark7@gmail.com'),
(16, 'munawark7@gmail.com'),
(17, 'munawark7@gmail.com'),
(18, 'munawark7@gmail.com'),
(19, 'munawark7@gmail.com'),
(20, 'munawark7@gmail.com'),
(21, 'munawark7@gmail.com'),
(22, 'munawark7@gmail.com'),
(23, 'munawark7@gmail.com'),
(24, 'fahim@gmail.com'),
(25, 'munawark7@gmail.com'),
(26, 'asif@gmail.com'),
(27, 'rahim@gmail.com'),
(28, 'rahim@gmail.com'),
(29, 'munawark7@gmail.com'),
(30, 'munawark7@gmail.com'),
(31, 'munawark7@gmail.com'),
(32, 'munawark7@gmail.com'),
(33, 'munawark7@gmail.com'),
(34, 'munawark7@gmail.com'),
(35, 'nadim@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student_register`
--
ALTER TABLE `student_register`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `teacher_register`
--
ALTER TABLE `teacher_register`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `temp`
--
ALTER TABLE `temp`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `temp2`
--
ALTER TABLE `temp2`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student_register`
--
ALTER TABLE `student_register`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `teacher_register`
--
ALTER TABLE `teacher_register`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `temp`
--
ALTER TABLE `temp`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `temp2`
--
ALTER TABLE `temp2`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
